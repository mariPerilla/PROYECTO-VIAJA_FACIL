document.addEventListener("DOMContentLoaded", function () {
  // 🧹 Limpiar localStorage al recargar la página
  localStorage.clear();  
 
  const resumenContent = document.getElementById("resumen-content");
 
  // Leer y guardar imagen como Base64
  function leerImagen(inputFile, callback) {
    const file = inputFile.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function (e) {
        callback(e.target.result); // Base64
      };
      reader.readAsDataURL(file);
    } else {
      callback(null); // Si no hay imagen
    }
  }
 
  // Guardar Origen
  function guardarOrigen(event) {
    event.preventDefault();
    const origen = document.getElementById("origenName").value;
    const imagenInput = document.getElementById("origenLogo");
 
    leerImagen(imagenInput, function (imagenBase64) {
      localStorage.setItem("origenViaje", origen);
      if (imagenBase64) {
        localStorage.setItem("imagenOrigen", imagenBase64);
      }
      mostrarResumen();
    });
  }
 
  // Guardar Destino
  function guardarDestino(event) {
    event.preventDefault();
    const destino = document.getElementById("destinoName").value;
    const imagenInput = document.getElementById("destinoLogo");
 
    leerImagen(imagenInput, function (imagenBase64) {
      localStorage.setItem("destinoViaje", destino);
      if (imagenBase64) {
        localStorage.setItem("imagenDestino", imagenBase64);
      }
      mostrarResumen();
    });
  }
 
  // Guardar Fechas
  function guardarSalida(event) {
    event.preventDefault();
    const salida = document.getElementById("salidaName").value;
    localStorage.setItem("fechaSalida", salida);
    mostrarResumen();
  }
 
  function guardarVuelta(event) {
    event.preventDefault();
    const vuelta = document.getElementById("vueltaName").value;
    localStorage.setItem("fechaVuelta", vuelta);
    mostrarResumen();
  }
 
  // Mostrar Resumen
  function mostrarResumen() {
    const origen = localStorage.getItem("origenViaje") || "(no definido)";
    const imagenOrigen = localStorage.getItem("imagenOrigen");
 
    const destino = localStorage.getItem("destinoViaje") || "(no definido)";
    const imagenDestino = localStorage.getItem("imagenDestino");
 
    const salida = localStorage.getItem("fechaSalida") || "(no definida)";
    const vuelta = localStorage.getItem("fechaVuelta") || "(no definida)";
 
    resumenContent.innerHTML = `
      <h3>Resumen del Viaje</h3>
      <p><strong>Origen:</strong> ${origen}</p>
      ${imagenOrigen ? `<img src="${imagenOrigen}" alt="Imagen Origen" style="max-width:150px;">` : ""}
      <p><strong>Destino:</strong> ${destino}</p>
      ${imagenDestino ? `<img src="${imagenDestino}" alt="Imagen Destino" style="max-width:150px;">` : ""}
      <p><strong>Fecha de salida:</strong> ${salida}</p>
      <p><strong>Fecha de vuelta:</strong> ${vuelta}</p>
    `;
  }
 
  // Eventos
  document.getElementById("addOrigenForm").addEventListener("submit", guardarOrigen);
  document.getElementById("addDestinoForm").addEventListener("submit", guardarDestino);
  document.getElementById("addSalidaForm").addEventListener("submit", guardarSalida);
  document.getElementById("addVueltaForm").addEventListener("submit", guardarVuelta);
 
  // Mostrar resumen al cargar la página (después de limpiar localStorage)
  mostrarResumen();
});